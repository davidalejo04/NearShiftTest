CREATE TABLE [dbo].[olist_order_reviews_dataset] (
    [review_id]               VARCHAR (8000) NULL,
    [order_id]                VARCHAR (8000) NULL,
    [review_score]            INT            NULL,
    [review_comment_title]    VARCHAR (8000) NULL,
    [review_comment_message]  VARCHAR (8000) NULL,
    [review_creation_date]    DATETIME2 (6)  NULL,
    [review_answer_timestamp] DATETIME2 (6)  NULL
);


GO