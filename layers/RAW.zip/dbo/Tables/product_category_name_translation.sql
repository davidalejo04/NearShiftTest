CREATE TABLE [dbo].[product_category_name_translation] (
    [product_category_name]         VARCHAR (8000) NULL,
    [product_category_name_english] VARCHAR (8000) NULL
);


GO