CREATE TABLE [dbo].[olist_customers_dataset] (
    [customer_id]              VARCHAR (8000) NULL,
    [customer_unique_id]       VARCHAR (8000) NULL,
    [customer_zip_code_prefix] INT            NULL,
    [customer_city]            VARCHAR (8000) NULL,
    [customer_state]           VARCHAR (8000) NULL
);


GO