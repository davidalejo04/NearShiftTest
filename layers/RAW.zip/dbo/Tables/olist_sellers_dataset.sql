CREATE TABLE [dbo].[olist_sellers_dataset] (
    [seller_id]              VARCHAR (8000) NULL,
    [seller_zip_code_prefix] INT            NULL,
    [seller_city]            VARCHAR (8000) NULL,
    [seller_state]           VARCHAR (8000) NULL
);


GO