CREATE TABLE [dbo].[olist_order_payments_dataset] (
    [order_id]             VARCHAR (8000) NULL,
    [payment_sequential]   INT            NULL,
    [payment_type]         VARCHAR (8000) NULL,
    [payment_installments] INT            NULL,
    [payment_value]        FLOAT (53)     NULL
);


GO