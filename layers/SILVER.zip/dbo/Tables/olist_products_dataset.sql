CREATE TABLE [dbo].[olist_products_dataset] (
    [product_id]            VARCHAR (8000) NULL,
    [product_category_name] VARCHAR (8000) NULL
);


GO