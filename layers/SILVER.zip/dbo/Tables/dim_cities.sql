CREATE TABLE [dbo].[dim_cities] (
    [geolocation_city] VARCHAR (8000) NULL
);


GO