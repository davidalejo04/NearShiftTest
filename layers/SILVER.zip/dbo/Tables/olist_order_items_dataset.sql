CREATE TABLE [dbo].[olist_order_items_dataset] (
    [order_id]   VARCHAR (8000) NULL,
    [product_id] VARCHAR (8000) NULL,
    [seller_id]  VARCHAR (8000) NULL
);


GO