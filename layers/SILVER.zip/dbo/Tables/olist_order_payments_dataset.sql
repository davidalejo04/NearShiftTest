CREATE TABLE [dbo].[olist_order_payments_dataset] (
    [order_id]      VARCHAR (8000) NULL,
    [payment_value] FLOAT (53)     NULL
);


GO