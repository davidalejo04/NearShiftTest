CREATE TABLE [dbo].[dim_calendar] (
    [date_key]     INT            NULL,
    [full_date]    DATE           NULL,
    [year]         INT            NULL,
    [quarter]      INT            NULL,
    [month]        INT            NULL,
    [month_name]   VARCHAR (8000) NULL,
    [day_of_month] INT            NULL,
    [week_of_year] INT            NULL,
    [day_of_week]  INT            NULL,
    [day_name]     VARCHAR (8000) NULL
);


GO