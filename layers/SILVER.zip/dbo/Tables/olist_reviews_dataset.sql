CREATE TABLE [dbo].[olist_reviews_dataset] (
    [review_id]                 VARCHAR (8000) NULL,
    [order_id]                  VARCHAR (8000) NULL,
    [review_score]              INT            NULL,
    [review_creation_date]      DATETIME2 (6)  NULL,
    [review_creation_date_date] DATE           NULL
);


GO