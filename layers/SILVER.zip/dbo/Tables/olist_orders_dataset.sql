CREATE TABLE [dbo].[olist_orders_dataset] (
    [order_id]                           VARCHAR (8000) NULL,
    [customer_id]                        VARCHAR (8000) NULL,
    [order_status]                       VARCHAR (8000) NULL,
    [order_purchase_timestamp]           DATETIME2 (6)  NULL,
    [order_delivered_customer_date]      DATETIME2 (6)  NULL,
    [order_estimated_delivery_date]      DATETIME2 (6)  NULL,
    [order_purchase_timestamp_date]      DATE           NULL,
    [order_delivered_customer_date_date] DATE           NULL,
    [order_estimated_delivery_date_date] DATE           NULL
);


GO